print("Standalone workspace restored!")
